config = 
{
	["url"] = "https://jabog32-fpt.herokuapp.com/mdc/Jabba",
}
