Add this to the export.lua file:

local mdclfs=require('lfs'); dofile(mdclfs.writedir().."Mods\\tech\\mdc\\export.lua")
